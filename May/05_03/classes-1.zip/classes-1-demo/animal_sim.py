from animals import Animal


gidget = Animal("Gidget", "dog")

fifi = Animal("Fifi", "salamander")

Animal.print_animals([gidget, fifi])


